### [Standard Notes](https://standardnotes.org/)

#### Install manually

1. Extensions → Import extension and paste this link: ` https://cdn.jsdelivr.net/gh/dracula/sn-theme-dracula/sn-theme-dracula.json `

2. Click 'Install'

3. Activate the theme!

4. Boom! It's working
